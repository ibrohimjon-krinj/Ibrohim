# Ibrohim
# Hi there, I'm Ibrohimjon 👋

📫 How to reach me: ibrohimurazaliyev7274@gmail.com

🔭 I'm currently learning frontend development.
💬 Ask me about HTML, CSS, JavaScript, Pug.
🎓 Education: FreeCodeCamp, Codecademy

## 🌐 Socials:
[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=flat&logo=telegram&logoColor=white)](https://t.me/yourtelegram)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?style=flat&logo=linkedin)](https://linkedin.com/in/yourprofile)

## 🛠️ Skills:
![HTML5](https://img.shields.io/badge/-HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/-CSS3-1572B6?style=flat&logo=css3)
![JavaScript](https://img.shields.io/badge/-JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)

![Your image](https://yourimageurl.com)  <!-- Rasm linkini joylang -->
